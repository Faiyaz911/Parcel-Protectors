import cv2
import os
import numpy as np

# Path to dataset folder
dataset_path = "Captured_Images"

# Create an LBPH face recognizer
recognizer = cv2.face.LBPHFaceRecognizer_create()

# Load OpenCV's face detector
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

# Function to load images and train the AI
def prepare_training_data():
    faces = []
    labels = []
    label_map = {}  # Mapping between label numbers and names
    label_id = 0  # Unique ID for each person
    
    for person_name in os.listdir(dataset_path):
        person_folder = os.path.join(dataset_path, person_name)
        if not os.path.isdir(person_folder):
            continue  # Skip if it's not a folder
        
        print(f"Processing images for {person_name}...")
        label_map[label_id] = person_name  # Map label ID to person's name

        for image_name in os.listdir(person_folder):
            image_path = os.path.join(person_folder, image_name)
            if image_path.endswith(".jpg") or image_path.endswith(".png"):
                # Read the image and convert to grayscale
                image = cv2.imread(image_path)
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

                # Detect face in the image
                faces_detected = face_cascade.detectMultiScale(gray, 1.3, 5)
                
                for (x, y, w, h) in faces_detected:
                    face_region = gray[y:y + h, x:x + w]  # Extract face
                    faces.append(face_region)
                    labels.append(label_id)  # Assign label based on person's ID
        
        label_id += 1  # Increment for next person
    
    return faces, np.array(labels), label_map

# Load dataset and train AI
faces, labels, label_map = prepare_training_data()

# Train the recognizer
print("Training AI model...")
recognizer.train(faces, labels)

# Save the trained model
trainer_file = "trainer.yml"
recognizer.save(trainer_file)
print(f"Training complete. Model saved as {trainer_file}.")

# Save the label map to a text file
with open("label_map.txt", "w") as f:
    for label, name in label_map.items():
        f.write(f"{label},{name}\n")

print("Label mapping saved as label_map.txt.")
