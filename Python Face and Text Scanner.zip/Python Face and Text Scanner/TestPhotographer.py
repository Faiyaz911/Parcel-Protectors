import cv2
import os

# Create a folder to store images if it doesn't exist
folder_name = "Captured_Images/Faiyaz Sajjad"
os.makedirs(folder_name, exist_ok=True)

# Open the webcam
record = cv2.VideoCapture(0)

# Check if the webcam is open
if not record.isOpened():
    print("Error: Could not open webcam.")
    exit()

image_count = 1  # Initialize the image counter
max_images = 25   # Maximum number of images to capture

print("Press 's' to capture a photo or 'q' to quit.")

while image_count <= max_images:
    # Capture a frame from the webcam
    ret, frame = record.read()

    if not ret:
        print("Error capturing image.")
        break

    # Display the live feed
    cv2.imshow("Press 's' to Capture, 'q' to Quit", frame)

    # Wait for the user to press a key
    key = cv2.waitKey(1) & 0xFF

    if key == ord('s'):  # If 's' is pressed, capture and save the image
        image_path = os.path.join(folder_name, f"captured_image_{image_count}.jpg")  # Unique filename
        cv2.imwrite(image_path, frame)  # Save the captured image to the folder
        print(f"Image {image_count} saved at: {image_path}")
        image_count += 1  # Increment the image counter

    elif key == ord('q'):  # If 'q' is pressed, quit without saving
        print("Exiting...")
        break

# Release the webcam and close OpenCV windows
record.release()
cv2.destroyAllWindows()
