import cv2
import os
import numpy as np
import keyboard

print("Press 'a' to continue...")
while True:
    key = msvcrt.getch().decode('utf-8')  # Get a single key press
    if key == 'a':
        name = input("What's your name: ")

    print(f"Your name is {name}")

    folder_name = f"Captured_Images/{name}"
    os.makedirs(folder_name, exist_ok=True)


    print(f"{name} you've been added")
    break

