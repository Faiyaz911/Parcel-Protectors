import cv2
import os
import numpy as np
import keyboard

# Path to dataset folder
dataset_path = "Captured_Images"

# Load the trained face recognizer model
recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read("trainer.yml")  # Load trained model

# Load the Haar cascade classifier for face detection
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

# Open webcam
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Couldn't access the webcam")
    exit()

while True:
    ret, frame = cap.read()
    if not ret:
        print("Error capturing frame")
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=6)

    for (x, y, w, h) in faces:
        face_roi = gray[y:y+h, x:x+w]
        label, confidence = recognizer.predict(face_roi)

        if confidence < 55:
            text = f"Recognized (Conf: {round(confidence, 2)})"
            color = (0, 255, 0)
        else:
            text = f"Unknown (Conf: {round(confidence, 2)})"
            color = (0, 0, 255)

        cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
        cv2.putText(frame, text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

    cv2.imshow("Face Recognition", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    
    if keyboard.is_pressed('a'):
        cap.release()
        cv2.destroyAllWindows()
        while True:
            name = input("What's your name: ")
            print(f"Your name is {name}")
            
            folder_name = os.path.join("Captured_Images", name)
            os.makedirs(folder_name, exist_ok=True)

            record = cv2.VideoCapture(0)
            if not record.isOpened():
                print("Error: Could not open webcam.")
                exit()

            image_count = 1
            max_images = 25
            print("Press 's' to capture a photo or 'q' to quit.")

            while image_count <= max_images:
                ret, frame = record.read()
                if not ret:
                    print("Error capturing image.")
                    break

                cv2.imshow("Press 's' to Capture, 'q' to Quit", frame)
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('s'):
                    image_path = os.path.join(folder_name, f"captured_image_{image_count}.jpg")
                    cv2.imwrite(image_path, frame)
                    print(f"Image {image_count} saved at: {image_path}")
                    image_count += 1
                elif key == ord('q'):
                    print("Exiting...")
                    break

            record.release()
            cv2.destroyAllWindows()
            print(f"{name}, you've been added")
            break    

cap.release()
cv2.destroyAllWindows()

# Function to load images and train the AI
def prepare_training_data():
    faces = []
    labels = []
    label_map = {}
    label_id = 0
    
    for person_name in os.listdir(dataset_path):
        person_folder = os.path.join(dataset_path, person_name)
        if not os.path.isdir(person_folder):
            continue
        
        print(f"Processing images for {person_name}...")
        label_map[label_id] = person_name

        for image_name in os.listdir(person_folder):
            image_path = os.path.join(person_folder, image_name)
            if image_path.endswith(".jpg") or image_path.endswith(".png"):
                image = cv2.imread(image_path)
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                faces_detected = face_cascade.detectMultiScale(gray, 1.3, 5)
                
                for (x, y, w, h) in faces_detected:
                    face_region = gray[y:y + h, x:x + w]
                    faces.append(face_region)
                    labels.append(label_id)
        
        label_id += 1
    
    return faces, np.array(labels), label_map

# Load dataset and train AI
faces, labels, label_map = prepare_training_data()

print("Training AI model...")
recognizer.train(faces, labels)
recognizer.save("trainer.yml")
print("Training complete. Model saved as trainer.yml.")

with open("label_map.txt", "w") as f:
    for label, name in label_map.items():
        f.write(f"{label},{name}\n")

print("Label mapping saved as label_map.txt.")
